"""
phase1_preprocessing.py
Data Preprocessing phase for the Cross-Model / Cross-Dataset XAI project.

For each dataset:
  1. Load raw file (download it first if a direct URL exists).
  2. Clean / rename target to `Default` (1 = bad credit / default, 0 = good).
  3. Impute missing values.
  4. One-hot encode categoricals.
  5. Downcast dtypes (float64->float32, int64->smallest safe int).
  6. 80/20 stratified train/test split.
  7. Save as parquet to data/processed/<dataset>_train.parquet / _test.parquet.

Run:
    python phase1_preprocessing.py               # runs all datasets it can find
    python phase1_preprocessing.py --dataset german
"""

import argparse
import gc
import sys
import urllib.request

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from config import DATASETS, RAW_DIR, PROCESSED_DIR, RANDOM_SEED, TARGET_COL
from mem_utils import downcast_dataframe, report_memory


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------

def ensure_raw_file(dataset_key: str) -> "pd.io.common.IOArgumentType":
    """Download the raw file if a direct URL is registered and the file
    isn't already present locally. Raises a clear, actionable error if the
    file is missing and can't be auto-fetched (GMSC, Taiwan)."""
    meta = DATASETS[dataset_key]
    path = RAW_DIR / meta["raw_filename"]

    if path.exists():
        return path

    if meta["download_url"] is not None:
        print(f"  Downloading {dataset_key} -> {path.name} ...")
        urllib.request.urlretrieve(meta["download_url"], path)
        return path

    raise FileNotFoundError(
        f"\n[{dataset_key}] Raw file not found at {path}\n"
        f"This dataset requires manual download (Kaggle/UCI login-gated):\n"
        f"  german  : auto-downloaded, should not hit this branch\n"
        f"  gmsc    : Kaggle 'Give Me Some Credit' -> download 'cs-training.csv'\n"
        f"            https://www.kaggle.com/c/GiveMeSomeCredit/data\n"
        f"            place it at: {RAW_DIR}/cs-training.csv\n"
        f"  taiwan  : UCI 'default of credit card clients' -> 'UCI_Credit_Card.csv'\n"
        f"            https://archive.ics.uci.edu/dataset/350/default+of+credit+card+clients\n"
        f"            place it at: {RAW_DIR}/UCI_Credit_Card.csv\n"
        f"Re-run this script once the file is in place.\n"
    )


def split_and_save(df: pd.DataFrame, dataset_key: str) -> None:
    """80/20 stratified split on Default, downcast, save to parquet."""
    assert TARGET_COL in df.columns, f"{TARGET_COL} column missing before split"

    X = df.drop(columns=[TARGET_COL])
    y = df[TARGET_COL]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_SEED, stratify=y
    )

    train_df = X_train.copy()
    train_df[TARGET_COL] = y_train.values
    test_df = X_test.copy()
    test_df[TARGET_COL] = y_test.values

    train_df = downcast_dataframe(train_df, verbose=True)
    test_df = downcast_dataframe(test_df, verbose=True)

    train_path = PROCESSED_DIR / f"{dataset_key}_train.parquet"
    test_path = PROCESSED_DIR / f"{dataset_key}_test.parquet"
    train_df.to_parquet(train_path, index=False)
    test_df.to_parquet(test_path, index=False)

    print(f"  Saved: {train_path.name} ({train_df.shape}), "
          f"{test_path.name} ({test_df.shape})")
    print(f"  Default rate  train={train_df[TARGET_COL].mean():.3f}  "
          f"test={test_df[TARGET_COL].mean():.3f}")

    del X, y, X_train, X_test, y_train, y_test, train_df, test_df
    gc.collect()


# ---------------------------------------------------------------------------
# Dataset-specific cleaners
# ---------------------------------------------------------------------------

def clean_german(path) -> pd.DataFrame:
    """Statlog German Credit (original categorical-coded format, 21 cols)."""
    columns = [
        "checking_status", "duration", "credit_history", "purpose",
        "credit_amount", "savings_status", "employment", "installment_rate",
        "personal_status", "other_parties", "residence_since",
        "property_magnitude", "age", "other_payment_plans", "housing",
        "existing_credits", "job", "num_dependents", "own_telephone",
        "foreign_worker", "target",
    ]
    df = pd.read_csv(path, header=None, names=columns)

    # Original encoding: 1 = good credit, 2 = bad credit (=default)
    df[TARGET_COL] = (df["target"] == 2).astype(np.int64)
    df = df.drop(columns=["target"])

    # No missing values in this dataset by construction (Statlog original),
    # but we impute defensively so the pipeline is robust if that changes.
    numeric_cols = df.select_dtypes(include=[np.number]).columns.drop(TARGET_COL)
    categorical_cols = df.select_dtypes(exclude=[np.number]).columns

    for c in numeric_cols:
        df[c] = df[c].fillna(df[c].median())
    for c in categorical_cols:
        df[c] = df[c].fillna(df[c].mode().iloc[0])

    df = pd.get_dummies(df, columns=list(categorical_cols), drop_first=True)
    # get_dummies produces bool dtype columns in modern pandas -> cast to
    # int64 first so downcast_dataframe's int64->int8 logic picks them up
    bool_cols = df.select_dtypes(include=["bool"]).columns
    df[bool_cols] = df[bool_cols].astype(np.int64)

    return df


def clean_gmsc(path) -> pd.DataFrame:
    """Kaggle 'Give Me Some Credit' (cs-training.csv)."""
    df = pd.read_csv(path)
    # First column is an unnamed row index in the raw Kaggle file
    if df.columns[0].lower().startswith("unnamed"):
        df = df.drop(columns=[df.columns[0]])

    df = df.rename(columns={"SeriousDlqin2yrs": TARGET_COL})
    df[TARGET_COL] = df[TARGET_COL].astype(np.int64)

    numeric_cols = df.select_dtypes(include=[np.number]).columns.drop(TARGET_COL)
    for c in numeric_cols:
        df[c] = df[c].fillna(df[c].median())

    # MonthlyIncome and NumberOfDependents are the two columns with real
    # missingness in this dataset (~20% and ~2.6% respectively) — median
    # imputation is a defensible, simple baseline for a UROP-scope paper;
    # note this as a limitation / future work (e.g. MICE) in your writeup.
    return df


def clean_taiwan(path) -> pd.DataFrame:
    """UCI 'default of credit card clients' (UCI_Credit_Card.csv)."""
    df = pd.read_csv(path)
    if "ID" in df.columns:
        df = df.drop(columns=["ID"])

    target_candidates = [c for c in df.columns if "default" in c.lower()]
    assert len(target_candidates) == 1, (
        f"Expected exactly one default-related column, found {target_candidates}"
    )
    df = df.rename(columns={target_candidates[0]: TARGET_COL})
    df[TARGET_COL] = df[TARGET_COL].astype(np.int64)

    numeric_cols = df.select_dtypes(include=[np.number]).columns.drop(TARGET_COL)
    for c in numeric_cols:
        df[c] = df[c].fillna(df[c].median())

    # SEX, EDUCATION, MARRIAGE are integer-coded categoricals in the raw
    # file; one-hot encode them so all three datasets end up with a
    # consistent "numeric + one-hot" feature representation for Phase 2-4.
    categorical_cols = [c for c in ["SEX", "EDUCATION", "MARRIAGE"] if c in df.columns]
    df = pd.get_dummies(df, columns=categorical_cols, drop_first=True)
    bool_cols = df.select_dtypes(include=["bool"]).columns
    df[bool_cols] = df[bool_cols].astype(np.int64)

    return df


CLEANERS = {
    "german": clean_german,
    "gmsc": clean_gmsc,
    "taiwan": clean_taiwan,
}


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

def run_dataset(dataset_key: str) -> bool:
    print(f"\n=== Phase 1: {dataset_key} ===")
    try:
        raw_path = ensure_raw_file(dataset_key)
    except FileNotFoundError as e:
        print(str(e))
        return False

    df = CLEANERS[dataset_key](raw_path)
    report_memory(df, name=f"{dataset_key} (post-clean, pre-downcast)")
    assert df.isnull().sum().sum() == 0, "Unexpected NaNs remain after imputation"
    assert df[TARGET_COL].isin([0, 1]).all(), "Default column must be binary"

    split_and_save(df, dataset_key)
    del df
    gc.collect()
    return True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=list(DATASETS.keys()), default=None,
                         help="Run a single dataset; default runs all available.")
    args = parser.parse_args()

    targets = [args.dataset] if args.dataset else list(DATASETS.keys())
    results = {k: run_dataset(k) for k in targets}

    print("\n=== Phase 1 summary ===")
    for k, ok in results.items():
        print(f"  {k:8s}: {'OK' if ok else 'SKIPPED (raw file missing)'}")

    if not all(results.values()):
        print("\nSome datasets were skipped. Download the missing raw files "
              "per the instructions above, then re-run this script.")
        sys.exit(0)  # not a hard failure — German alone is enough to keep building


if __name__ == "__main__":
    main()
